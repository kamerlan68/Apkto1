package com.bigtools.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.OpenableColumns
import android.provider.Settings
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Util {
    fun storageRoot(): File = Environment.getExternalStorageDirectory()

    fun appDir(sub: String): File {
        val d = File(storageRoot(), "BigTools/$sub")
        d.mkdirs()
        return d
    }

    fun hasAccess(c: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= 30) {
            Environment.isExternalStorageManager()
        } else {
            c.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
                c.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun requestAccess(a: Activity) {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                a.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + a.packageName)))
            } catch (e: Exception) {
                a.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            a.requestPermissions(
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 1
            )
        }
    }

    fun size(n: Long): String {
        if (n < 1024) return "$n B"
        val u = arrayOf("KB", "MB", "GB", "TB")
        var v = n.toDouble()
        var i = -1
        while (v >= 1024 && i < u.size - 1) { v /= 1024; i++ }
        return String.format(Locale.US, "%.1f %s", v, u[i])
    }

    fun date(t: Long): String = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(t))

    fun ext(name: String): String {
        val i = name.lastIndexOf('.')
        return if (i < 0 || i == name.length - 1) "" else name.substring(i + 1).lowercase(Locale.ROOT)
    }

    fun isZipLike(name: String): Boolean = ext(name) in setOf("zip", "apk", "jar", "xapk", "apks", "apkm", "aab", "obb", "war", "epub", "docx", "xlsx", "pptx", "odt", "mcpack")

    fun isText(name: String): Boolean = ext(name) in setOf(
        "txt", "xml", "json", "html", "htm", "js", "css", "smali", "properties", "md", "cfg", "ini", "log",
        "java", "kt", "yml", "yaml", "sh", "csv", "mf", "sf", "rc", "conf", "gradle", "pro", "kts", "tsv", "toml", "bat", "py", "lua", "sql"
    )

    fun mime(name: String): String {
        val m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext(name))
        if (m != null) return m
        return if (ext(name) == "apk") "application/vnd.android.package-archive" else "*/*"
    }

    fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ex = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (f.exists()) { f = File(dir, base + "_" + i + ex); i++ }
        return f
    }

    fun copyFile(src: File, dst: File) {
        dst.parentFile?.mkdirs()
        FileInputStream(src).use { i -> FileOutputStream(dst).use { o -> i.copyTo(o, 64 * 1024) } }
    }

    fun copyRec(src: File, dst: File) {
        if (src.isDirectory) {
            dst.mkdirs()
            src.listFiles()?.forEach { copyRec(it, File(dst, it.name)) }
        } else copyFile(src, dst)
    }

    fun deleteRec(f: File): Boolean {
        if (f.isDirectory) f.listFiles()?.forEach { deleteRec(it) }
        return f.delete()
    }

    fun dirSize(f: File): Long {
        if (f.isFile) return f.length()
        var s = 0L
        f.listFiles()?.forEach { s += dirSize(it) }
        return s
    }

    fun hash(f: File, algo: String): String {
        val md = MessageDigest.getInstance(algo)
        FileInputStream(f).use { i ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = i.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        val sb = StringBuilder()
        for (b in md.digest()) sb.append(String.format("%02x", b))
        return sb.toString()
    }

    fun uriFor(c: Context, f: File): Uri = FileProvider.getUriForFile(c, c.packageName + ".provider", f)

    fun share(c: Context, f: File) {
        val i = Intent(Intent.ACTION_SEND)
        i.type = mime(f.name)
        i.putExtra(Intent.EXTRA_STREAM, uriFor(c, f))
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        c.startActivity(Intent.createChooser(i, "Поделиться: " + f.name))
    }

    fun installApk(c: Context, f: File) {
        if (Build.VERSION.SDK_INT >= 26 && !c.packageManager.canRequestPackageInstalls()) {
            Ui.toast(c, "Разреши BigTools устанавливать приложения и повтори")
            c.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + c.packageName)))
            return
        }
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(uriFor(c, f), "application/vnd.android.package-archive")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        c.startActivity(i)
    }

    fun displayName(c: Context, uri: Uri): String {
        var n: String? = null
        try {
            c.contentResolver.query(uri, null, null, null, null)?.use { cur ->
                if (cur.moveToFirst()) {
                    val idx = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) n = cur.getString(idx)
                }
            }
        } catch (_: Exception) {}
        return n ?: (uri.lastPathSegment ?: "file").substringAfterLast('/')
    }

    fun copyUriToCache(c: Context, uri: Uri): File {
        val dir = File(c.cacheDir, "picked")
        dir.mkdirs()
        val f = File(dir, displayName(c, uri).replace('/', '_'))
        val ins = c.contentResolver.openInputStream(uri) ?: throw java.io.IOException("Не удалось открыть файл")
        ins.use { i -> FileOutputStream(f).use { o -> i.copyTo(o, 64 * 1024) } }
        return f
    }
}
