package com.bigtools.app

import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Читалка бинарного XML (AndroidManifest.xml и res XML files) → текст. Только просмотр. */
object Axml {
    fun looksLikeAxml(d: ByteArray): Boolean =
        d.size > 8 && d[0].toInt() == 0x03 && d[1].toInt() == 0x00 && d[2].toInt() == 0x08 && d[3].toInt() == 0x00

    private fun readPool(b: ByteBuffer, pos: Int): List<String> {
        val count = b.getInt(pos + 8)
        val flags = b.getInt(pos + 16)
        val stringsStart = b.getInt(pos + 20)
        val utf8 = (flags and 0x100) != 0
        val out = ArrayList<String>(count)
        for (i in 0 until count) {
            val off = b.getInt(pos + 28 + i * 4)
            var p = pos + stringsStart + off
            if (utf8) {
                var l = b.get(p).toInt() and 0xFF
                p += if (l and 0x80 != 0) 2 else 1
                var bl = b.get(p).toInt() and 0xFF
                if (bl and 0x80 != 0) {
                    bl = ((bl and 0x7F) shl 8) or (b.get(p + 1).toInt() and 0xFF)
                    p += 2
                } else p += 1
                val bytes = ByteArray(bl)
                for (k in 0 until bl) bytes[k] = b.get(p + k)
                out.add(String(bytes, Charsets.UTF_8))
            } else {
                var l = b.getShort(p).toInt() and 0xFFFF
                p += 2
                if (l and 0x8000 != 0) {
                    l = ((l and 0x7FFF) shl 16) or (b.getShort(p).toInt() and 0xFFFF)
                    p += 2
                }
                val sb = StringBuilder()
                for (k in 0 until l) sb.append((b.getShort(p + k * 2).toInt() and 0xFFFF).toChar())
                out.add(sb.toString())
            }
        }
        return out
    }

    fun decode(d: ByteArray): String {
        val b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
        if (!looksLikeAxml(d)) throw IOException("Не бинарный XML")
        var pos = 8
        var strings: List<String> = emptyList()
        val ns = HashMap<String, String>()
        val sb = StringBuilder("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n")
        var depth = 0
        fun s(i: Int): String = if (i >= 0 && i < strings.size) strings[i] else ""
        while (pos + 8 <= d.size) {
            val type = b.getShort(pos).toInt() and 0xFFFF
            val size = b.getInt(pos + 4)
            if (size <= 0) break
            when (type) {
                0x0001 -> strings = readPool(b, pos)
                0x0100 -> ns[s(b.getInt(pos + 20))] = s(b.getInt(pos + 16))
                0x0102 -> {
                    val base = pos + 16
                    val nsI = b.getInt(base)
                    val name = s(b.getInt(base + 4))
                    val attrStart = b.getShort(base + 8).toInt() and 0xFFFF
                    val attrCount = b.getShort(base + 12).toInt() and 0xFFFF
                    sb.append("  ".repeat(depth)).append('<').append(name)
                    var ap = base + attrStart
                    for (k in 0 until attrCount) {
                        val aNs = b.getInt(ap)
                        val aName = s(b.getInt(ap + 4))
                        val raw = b.getInt(ap + 8)
                        val dt = b.get(ap + 15).toInt() and 0xFF
                        val data = b.getInt(ap + 16)
                        val prefix = if (aNs >= 0) ns[s(aNs)] else null
                        val v = when (dt) {
                            0x03 -> s(raw)
                            0x01 -> String.format("@0x%08x", data)
                            0x02 -> String.format("?0x%08x", data)
                            0x10 -> data.toString()
                            0x11 -> String.format("0x%x", data)
                            0x12 -> if (data != 0) "true" else "false"
                            0x04 -> java.lang.Float.intBitsToFloat(data).toString()
                            in 0x1c..0x1f -> String.format("#%08x", data)
                            else -> String.format("0x%x", data)
                        }
                        sb.append(' ')
                        if (prefix != null && prefix.isNotEmpty()) sb.append(prefix).append(':')
                        sb.append(aName).append("=\"").append(v.replace("&", "&amp;").replace("\"", "&quot;")).append('"')
                        ap += 20
                    }
                    sb.append(">\n")
                    depth++
                }
                0x0103 -> {
                    depth = if (depth > 0) depth - 1 else 0
                    sb.append("  ".repeat(depth)).append("</").append(s(b.getInt(pos + 20))).append(">\n")
                }
                0x0104 -> sb.append("  ".repeat(depth)).append(s(b.getInt(pos + 16))).append('\n')
            }
            pos += size
        }
        return sb.toString()
    }
}
