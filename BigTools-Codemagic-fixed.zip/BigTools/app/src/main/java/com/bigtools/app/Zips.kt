package com.bigtools.app

import android.content.Context
import com.android.apksig.ApkSigner
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.FilterOutputStream
import java.io.IOException
import java.io.OutputStream
import java.security.KeyFactory
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

object Zips {
    class Ent(val name: String, val size: Long, val csize: Long, val dir: Boolean, val time: Long, val method: Int)

    class Counting(o: OutputStream) : FilterOutputStream(o) {
        var n = 0L
        override fun write(b: Int) { out.write(b); n++ }
        override fun write(b: ByteArray, off: Int, len: Int) { out.write(b, off, len); n += len.toLong() }
    }

    /** Копия исходника рядом (.bak) перед первой правкой. */
    fun backupOnce(f: File) {
        val b = File(f.path + ".bak")
        if (!b.exists()) Util.copyFile(f, b)
    }

    fun list(f: File): List<Ent> {
        val r = ArrayList<Ent>()
        ZipFile(f).use { z ->
            val en = z.entries()
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                r.add(Ent(e.name, e.size, e.compressedSize, e.isDirectory, e.time, e.method))
            }
        }
        return r
    }

    /** Распаковка (всё или только то, что начинается с prefix). Защита от zip-slip. */
    fun extract(zip: File, dest: File, prefix: String = ""): Int {
        dest.mkdirs()
        val base = dest.canonicalPath + File.separator
        var n = 0
        ZipFile(zip).use { z ->
            val en = z.entries()
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                if (prefix.isNotEmpty() && !e.name.startsWith(prefix)) continue
                val out = File(dest, e.name)
                if (!(out.canonicalPath + File.separator).startsWith(base)) continue
                if (e.isDirectory) { out.mkdirs(); continue }
                out.parentFile?.mkdirs()
                z.getInputStream(e).use { i -> FileOutputStream(out).use { o -> i.copyTo(o, 64 * 1024) } }
                n++
            }
        }
        return n
    }

    fun extractEntry(zip: File, name: String, dest: File) {
        ZipFile(zip).use { z ->
            val e = z.getEntry(name) ?: throw IOException("Нет записи $name")
            dest.parentFile?.mkdirs()
            z.getInputStream(e).use { i -> FileOutputStream(dest).use { o -> i.copyTo(o, 64 * 1024) } }
        }
    }

    fun readEntry(zip: File, name: String, limit: Int): ByteArray {
        val bo = java.io.ByteArrayOutputStream()
        ZipFile(zip).use { z ->
            val e = z.getEntry(name) ?: throw IOException("Нет записи $name")
            z.getInputStream(e).use { i ->
                val buf = ByteArray(32 * 1024)
                while (bo.size() < limit) {
                    val n = i.read(buf)
                    if (n < 0) break
                    bo.write(buf, 0, n)
                }
            }
        }
        return bo.toByteArray()
    }

    fun compress(src: File, dest: File) {
        val base = src.parentFile ?: src
        val destCanon = dest.canonicalPath
        ZipOutputStream(BufferedOutputStream(FileOutputStream(dest))).use { z ->
            fun add(f: File) {
                if (f.canonicalPath == destCanon) return
                val rel = f.relativeTo(base).path.replace(File.separatorChar, '/')
                if (f.isDirectory) {
                    z.putNextEntry(ZipEntry("$rel/"))
                    z.closeEntry()
                    f.listFiles()?.forEach { add(it) }
                } else {
                    z.putNextEntry(ZipEntry(rel))
                    FileInputStream(f).use { it.copyTo(z, 64 * 1024) }
                    z.closeEntry()
                }
            }
            add(src)
        }
    }

    private fun align(ze: ZipEntry, co: Counting, alignment: Int) {
        val nameLen = ze.name.toByteArray(Charsets.UTF_8).size
        val rest = ((co.n + 30 + nameLen) % alignment).toInt()
        var need = (alignment - rest) % alignment
        if (need == 0) return
        while (need < 4) need += alignment
        val extra = ByteArray(need)
        extra[0] = 0x35
        extra[1] = 0xD9.toByte()
        val dl = need - 4
        extra[2] = (dl and 0xFF).toByte()
        extra[3] = ((dl shr 8) and 0xFF).toByte()
        ze.extra = extra
    }

    private fun copyEntry(zf: ZipFile, e: ZipEntry, zos: ZipOutputStream, co: Counting) {
        val ne = ZipEntry(e.name)
        if (e.method == ZipEntry.STORED) {
            ne.method = ZipEntry.STORED
            ne.size = e.size
            ne.compressedSize = e.size
            ne.crc = e.crc
            align(ne, co, if (e.name.endsWith(".so")) 16384 else 4)
        } else {
            ne.method = ZipEntry.DEFLATED
        }
        if (e.time != -1L) ne.time = e.time
        zos.putNextEntry(ne)
        if (!e.isDirectory) zf.getInputStream(e).use { it.copyTo(zos, 64 * 1024) }
        zos.closeEntry()
    }

    private fun putFile(zos: ZipOutputStream, co: Counting, name: String, f: File) {
        val ze = ZipEntry(name)
        if (name == "resources.arsc") {
            ze.method = ZipEntry.STORED
            ze.size = f.length()
            ze.compressedSize = f.length()
            val crc = CRC32()
            FileInputStream(f).use { i ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = i.read(buf)
                    if (n < 0) break
                    crc.update(buf, 0, n)
                }
            }
            ze.crc = crc.value
            align(ze, co, 4)
        } else {
            ze.method = ZipEntry.DEFLATED
        }
        zos.putNextEntry(ze)
        FileInputStream(f).use { it.copyTo(zos, 64 * 1024) }
        zos.closeEntry()
    }

    /**
     * Пересобирает архив. changes: имя записи -> файл (заменить/добавить) или null (удалить).
     * Хранимые записи выравниваются (resources.arsc, .so) как у zipalign.
     */
    fun rewrite(src: File, changes: Map<String, File?>) {
        val tmp = File(src.parentFile, src.name + ".tmp")
        ZipFile(src).use { zf ->
            val co = Counting(BufferedOutputStream(FileOutputStream(tmp)))
            ZipOutputStream(co).use { zos ->
                val written = HashSet<String>()
                val en = zf.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    if (changes.containsKey(e.name)) {
                        val f = changes[e.name]
                        if (f != null) { putFile(zos, co, e.name, f); written.add(e.name) }
                        continue
                    }
                    copyEntry(zf, e, zos, co)
                    written.add(e.name)
                }
                for ((n, f) in changes) {
                    if (f != null && n !in written) putFile(zos, co, n, f)
                }
            }
        }
        if (!src.delete()) { tmp.delete(); throw IOException("Не удалось заменить исходный файл") }
        if (!tmp.renameTo(src)) {
            Util.copyFile(tmp, src)
            tmp.delete()
        }
    }

    /** Подпись APK встроенным ключом BigTools (v1+v2+v3). */
    fun sign(c: Context, input: File, output: File) {
        val keyBytes = c.assets.open("sign_key.pk8").use { it.readBytes() }
        val key = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(keyBytes))
        val cert = c.assets.open("sign_cert.der").use {
            CertificateFactory.getInstance("X.509").generateCertificate(it) as X509Certificate
        }
        val cfg = ApkSigner.SignerConfig.Builder("bigtools", key, listOf(cert)).build()
        if (output.exists()) output.delete()
        ApkSigner.Builder(listOf(cfg))
            .setInputApk(input)
            .setOutputApk(output)
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .setV3SigningEnabled(true)
            .build()
            .sign()
    }
}
