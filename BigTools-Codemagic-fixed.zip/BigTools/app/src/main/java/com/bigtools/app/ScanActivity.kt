package com.bigtools.app

import android.app.Activity
import android.content.pm.ApplicationInfo
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

/** Антивирус-проверка: выбрать файл / закинуть через «Поделиться» / проверить все приложения. */
class ScanActivity : Activity() {
    private lateinit var verdict: TextView
    private lateinit var report: TextView
    private val REQ_PICK = 21
    @Volatile private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.root(this)
        root.addView(Ui.titleBar(this, "BigTools - Антивирус"))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        val m = Ui.dp(this, 3)
        bar.addView(Ui.button(this, "Выбрать файл") { pick() }, Ui.lp(0, Ui.WRAP, 1f, m))
        bar.addView(Ui.button(this, "Все приложения") { scanApps() }, Ui.lp(0, Ui.WRAP, 1f, m))
        root.addView(bar, Ui.lp(Ui.MATCH, Ui.WRAP))

        verdict = Ui.label(this, "Закинь файл: «Выбрать файл» или «Поделиться» → BigTools", 14f, true)
        verdict.gravity = android.view.Gravity.CENTER
        val p = Ui.dp(this, 12)
        verdict.setPadding(p, p, p, p)
        verdict.setBackgroundColor(Ui.GRAY)
        root.addView(verdict, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, Ui.dp(this, 3)))

        report = Ui.label(this, "", 11f)
        report.setTextIsSelectable(true)
        Ui.sunken(report, Ui.WHITE, 8)
        val sv = ScrollView(this)
        sv.addView(report)
        root.addView(sv, Ui.lp(Ui.MATCH, Ui.MATCH, 1f, Ui.dp(this, 4)))
        setContentView(root)

        handle(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) handle(intent)
    }

    @Suppress("DEPRECATION")
    private fun handle(i: Intent) {
        val path = i.getStringExtra("path")
        if (path != null) { scanFile(File(path)); return }
        if (i.action == Intent.ACTION_SEND) {
            val uri = i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            if (uri != null) scanUri(uri)
        }
    }

    private fun pick() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        startActivityForResult(i, REQ_PICK)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK && resultCode == RESULT_OK) {
            val uri = data?.data
            if (uri != null) scanUri(uri)
        }
    }

    private fun scanUri(uri: Uri) {
        Ui.work(this, "Проверка файла...", {
            val f = Util.copyUriToCache(this, uri)
            val r = Scanner.scan(this, f)
            f.delete()
            r
        }) { r -> show(r) }
    }

    private fun scanFile(f: File) {
        if (!f.isFile) { Ui.toast(this, "Это не файл"); return }
        Ui.work(this, "Проверка файла...", { Scanner.scan(this, f) }) { r -> show(r) }
    }

    private fun show(r: Scanner.Result) {
        verdict.text = r.title + "  [" + r.score + "]"
        if (r.level == 0) {
            verdict.setBackgroundColor(Ui.WHITE)
            verdict.setTextColor(Ui.BLACK)
        } else {
            verdict.setBackgroundColor(Ui.BLACK)
            verdict.setTextColor(Ui.WHITE)
        }
        report.text = r.report
    }

    @Suppress("DEPRECATION")
    private fun scanApps() {
        if (busy) return
        busy = true
        verdict.text = "Проверка приложений..."
        verdict.setBackgroundColor(Ui.GRAY)
        verdict.setTextColor(Ui.BLACK)
        report.text = ""
        Thread {
            val pm = packageManager
            val apps = pm.getInstalledApplications(0).filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 && it.packageName != packageName }
            val lines = ArrayList<Pair<Int, String>>()
            var idx = 0
            for (ai in apps) {
                idx++
                val label = pm.getApplicationLabel(ai).toString()
                val n = idx
                runOnUiThread { verdict.text = "Проверка $n / " + apps.size + ": " + label }
                try {
                    val r = Scanner.scan(this, File(ai.sourceDir))
                    val mark = when (r.level) { 3 -> "[!!!]"; 2 -> "[!! ]"; 1 -> "[ ! ]"; else -> "[ OK]" }
                    lines.add(Pair(r.level, mark + " " + label + " (" + ai.packageName + ") " + r.score))
                } catch (e: Exception) {
                    lines.add(Pair(1, "[ ? ] " + label + ": " + (e.message ?: "ошибка")))
                }
            }
            lines.sortByDescending { it.first }
            val bad = lines.count { it.first >= 1 }
            val sb = StringBuilder()
            sb.append("Проверено приложений: ").append(lines.size).append("\nТребуют внимания: ").append(bad).append("\n\n")
            for (l in lines) sb.append(l.second).append('\n')
            sb.append("\nОценка эвристическая: [ ! ] и [!! ] не значит вирус, смотри права приложения. Подробности: Приложения → приложение → Проверить на вирусы.")
            runOnUiThread {
                verdict.text = "Готово: подозрительных " + bad + " из " + lines.size
                if (bad == 0) {
                    verdict.setBackgroundColor(Ui.WHITE); verdict.setTextColor(Ui.BLACK)
                } else {
                    verdict.setBackgroundColor(Ui.BLACK); verdict.setTextColor(Ui.WHITE)
                }
                report.text = sb.toString()
                busy = false
            }
        }.start()
    }
}
