package com.bigtools.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.StatFs
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var access: android.widget.Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.root(this)
        root.addView(Ui.titleBar(this, "BigTools 1.0"))

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        val pad = Ui.dp(this, 12)
        body.setPadding(pad, pad, pad, pad)

        status = Ui.label(this, "", 12f)
        Ui.sunken(status, Ui.WHITE, 8)
        body.addView(status, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, Ui.dp(this, 4)))

        access = Ui.button(this, "Дать доступ к файлам") { Util.requestAccess(this) }
        body.addView(access, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, Ui.dp(this, 4)))

        fun big(text: String, cls: Class<*>) {
            val b = Ui.button(this, text) { startActivity(Intent(this, cls)) }
            b.textSize = 16f
            val p = Ui.dp(this, 16)
            b.setPadding(p, p, p, p)
            b.gravity = android.view.Gravity.START or android.view.Gravity.CENTER_VERTICAL
            body.addView(b, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, Ui.dp(this, 4)))
        }
        big("[1] Проводник файлов", ExplorerActivity::class.java)
        big("[2] Приложения / Extractor", AppsActivity::class.java)
        big("[3] Антивирус: проверить файл", ScanActivity::class.java)

        val about = Ui.label(
            this,
            "ZIP: распаковка и сжатие\nAPK: просмотр внутри, правка, подпись, установка\n" +
                "Extractor: достать APK приложения, поделиться\nПапка BigTools: /sdcard/BigTools\n\n" +
                "Правки APK делаются на самом файле, рядом сохраняется копия .bak. После правки APK нужно подписать (меню в APK).",
            11f
        )
        about.setPadding(pad, pad, pad, pad)
        body.addView(about)

        val sv = ScrollView(this)
        sv.addView(body)
        root.addView(sv, Ui.lp(Ui.MATCH, Ui.MATCH))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        val ok = Util.hasAccess(this)
        access.visibility = if (ok) android.view.View.GONE else android.view.View.VISIBLE
        var mem = ""
        try {
            val st = StatFs(Util.storageRoot().path)
            mem = "Память: свободно " + Util.size(st.availableBytes) + " из " + Util.size(st.totalBytes)
        } catch (_: Exception) {}
        status.text = "Доступ к файлам: " + (if (ok) "ДА" else "НЕТ") + "\n" + mem
    }
}
