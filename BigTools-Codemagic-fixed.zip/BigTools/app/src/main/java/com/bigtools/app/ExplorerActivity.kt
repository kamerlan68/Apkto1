package com.bigtools.app

import android.app.Activity
import android.content.Intent
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import java.io.File

class ExplorerActivity : Activity() {
    companion object {
        var clip: List<File> = emptyList()
        var clipMove = false
    }

    private var cur: File = Util.storageRoot()
    private var items: List<File> = emptyList()
    private var sortMode = 0
    private lateinit var pathView: TextView
    private lateinit var list: ListView
    private lateinit var pasteBtn: Button
    private lateinit var accessBtn: Button
    private val adapter = Adapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.root(this)
        root.addView(Ui.titleBar(this, "BigTools - Проводник"))

        pathView = Ui.label(this, "", 12f)
        Ui.sunken(pathView, Ui.WHITE, 6)
        root.addView(pathView, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, Ui.dp(this, 4)))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        val m = Ui.dp(this, 2)
        bar.addView(Ui.button(this, "Вверх") { up() }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, m))
        bar.addView(Ui.button(this, "Корень") { go(Util.storageRoot()) }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, m))
        bar.addView(Ui.button(this, "Создать") { createMenu() }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, m))
        pasteBtn = Ui.button(this, "Вставить") { paste() }
        bar.addView(pasteBtn, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, m))
        bar.addView(Ui.button(this, "Сорт.") { sortMenu() }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, m))
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(bar)
        root.addView(hs, Ui.lp(Ui.MATCH, Ui.WRAP))

        accessBtn = Ui.button(this, "Нет доступа к файлам - нажми, чтобы разрешить") { Util.requestAccess(this) }
        root.addView(accessBtn, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, Ui.dp(this, 4)))

        list = ListView(this)
        list.divider = ColorDrawable(Ui.DARK)
        list.dividerHeight = 1
        list.adapter = adapter
        Ui.sunken(list, Ui.WHITE, 2)
        list.setOnItemClickListener { _, _, pos, _ ->
            val f = items[pos]
            if (f.isDirectory) go(f) else fileMenu(f)
        }
        list.setOnItemLongClickListener { _, _, pos, _ -> fileMenu(items[pos]); true }
        root.addView(list, Ui.lp(Ui.MATCH, Ui.MATCH, 1f, Ui.dp(this, 4)))
        setContentView(root)

        val start = intent.getStringExtra("path")
        if (start != null && File(start).isDirectory) cur = File(start)
    }

    override fun onResume() {
        super.onResume()
        accessBtn.visibility = if (Util.hasAccess(this)) View.GONE else View.VISIBLE
        refresh()
    }

    override fun onBackPressed() {
        if (cur.path != Util.storageRoot().path && cur.parentFile != null) up() else super.onBackPressed()
    }

    private fun up() {
        val p = cur.parentFile
        if (p != null && p.canRead()) go(p) else Ui.toast(this, "Выше нельзя")
    }

    private fun go(d: File) {
        cur = d
        refresh()
    }

    private fun refresh() {
        pathView.text = cur.absolutePath
        val l = cur.listFiles()
        if (l == null) {
            items = emptyList()
            Ui.toast(this, "Нет доступа к папке")
        } else {
            val cmp: Comparator<File> = when (sortMode) {
                1 -> Comparator<File> { a, b -> b.length().compareTo(a.length()) }
                2 -> Comparator<File> { a, b -> b.lastModified().compareTo(a.lastModified()) }
                else -> Comparator<File> { a, b -> a.name.lowercase().compareTo(b.name.lowercase()) }
            }
            items = l.sortedWith(Comparator<File> { a, b ->
                if (a.isDirectory != b.isDirectory) (if (a.isDirectory) -1 else 1) else cmp.compare(a, b)
            })
        }
        pasteBtn.text = if (clip.isEmpty()) "Вставить" else "Вставить (" + clip.size + ")"
        adapter.notifyDataSetChanged()
    }

    private fun tag(f: File): String {
        if (f.isDirectory) return "[DIR]"
        val e = Util.ext(f.name)
        return when {
            e == "apk" -> "[APK]"
            Util.isZipLike(f.name) -> "[ZIP]"
            Util.isText(f.name) -> "[TXT]"
            e in setOf("jpg", "jpeg", "png", "gif", "webp", "bmp") -> "[IMG]"
            e in setOf("mp3", "wav", "ogg", "flac", "m4a") -> "[SND]"
            e in setOf("mp4", "mkv", "avi", "mov", "3gp") -> "[VID]"
            else -> "[   ]"
        }
    }

    inner class Adapter : BaseAdapter() {
        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row: LinearLayout
            if (convertView == null) {
                row = LinearLayout(this@ExplorerActivity)
                row.orientation = LinearLayout.VERTICAL
                val p = Ui.dp(this@ExplorerActivity, 8)
                row.setPadding(p, p, p, p)
                row.addView(Ui.label(this@ExplorerActivity, "", 14f, true))
                row.addView(Ui.label(this@ExplorerActivity, "", 11f))
            } else {
                row = convertView as LinearLayout
            }
            val f = items[position]
            (row.getChildAt(0) as TextView).text = tag(f) + " " + f.name
            val sub = if (f.isDirectory) {
                (f.list()?.size ?: 0).toString() + " элем.  " + Util.date(f.lastModified())
            } else {
                Util.size(f.length()) + "  " + Util.date(f.lastModified())
            }
            (row.getChildAt(1) as TextView).text = sub
            row.setBackgroundColor(if (position % 2 == 0) Ui.WHITE else 0xFFEEEEEE.toInt())
            return row
        }
    }

    private fun sortMenu() {
        Ui.menu(this, "Сортировка", listOf("По имени", "По размеру", "По дате")) { i -> sortMode = i; refresh() }
    }

    private fun createMenu() {
        Ui.menu(this, "Создать", listOf("Папку", "Текстовый файл")) { i ->
            Ui.ask(this, if (i == 0) "Имя папки" else "Имя файла", if (i == 0) "Новая папка" else "new.txt") { n ->
                if (n.isNotEmpty()) {
                    val f = File(cur, n)
                    val ok = try { if (i == 0) f.mkdirs() else f.createNewFile() } catch (e: Exception) { false }
                    if (!ok) Ui.toast(this, "Не удалось создать")
                    refresh()
                }
            }
        }
    }

    private fun paste() {
        if (clip.isEmpty()) { Ui.toast(this, "Буфер пуст. Выбери файл → Копировать / Вырезать"); return }
        val src = clip
        val move = clipMove
        Ui.work(this, if (move) "Перемещение..." else "Копирование...", {
            var n = 0
            for (s in src) {
                if (!s.exists()) continue
                if (s.isDirectory && (cur.canonicalPath + "/").startsWith(s.canonicalPath + "/")) continue
                val d = Util.uniqueFile(cur, s.name)
                if (move) {
                    if (!s.renameTo(d)) { Util.copyRec(s, d); Util.deleteRec(s) }
                } else Util.copyRec(s, d)
                n++
            }
            n
        }) { n ->
            if (move) clip = emptyList()
            Ui.toast(this, "Готово: $n")
            refresh()
        }
    }

    private fun fileMenu(f: File) {
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        fun add(l: String, a: () -> Unit) { labels.add(l); acts.add(a) }
        val zipLike = f.isFile && Util.isZipLike(f.name)
        val isApk = f.isFile && Util.ext(f.name) == "apk"

        if (f.isDirectory) add("Открыть") { go(f) }
        if (zipLike) add("Открыть внутри (ZIP/APK)") {
            startActivity(Intent(this, ZipActivity::class.java).putExtra("zip", f.absolutePath))
        }
        if (isApk) add("Установить APK") { Util.installApk(this, f) }
        if (isApk) add("Подписать APK (ключ BigTools)") { signApk(f) }
        if (zipLike) add("Распаковать сюда") { extractHere(f) }
        if (f.isFile && Util.isText(f.name)) add("Редактировать текст") { viewer(f, "auto") }
        if (f.isFile) add("Просмотр HEX") { viewer(f, "hex") }
        if (f.isFile) add("Проверить на вирусы") {
            startActivity(Intent(this, ScanActivity::class.java).putExtra("path", f.absolutePath))
        }
        add("Поделиться") { shareIt(f) }
        add("Сжать в ZIP") { compress(f) }
        add("Копировать") { clip = listOf(f); clipMove = false; Ui.toast(this, "Скопировано в буфер"); refresh() }
        add("Вырезать") { clip = listOf(f); clipMove = true; Ui.toast(this, "Вырезано в буфер"); refresh() }
        add("Переименовать") {
            Ui.ask(this, "Новое имя", f.name) { n ->
                if (n.isNotEmpty() && n != f.name) {
                    if (!f.renameTo(File(f.parentFile, n))) Ui.toast(this, "Не удалось переименовать")
                    refresh()
                }
            }
        }
        add("Удалить") {
            Ui.confirm(this, "Удалить " + f.name + (if (f.isDirectory) " вместе со всем содержимым?" else "?")) {
                Ui.work(this, "Удаление...", { Util.deleteRec(f) }) { ok ->
                    if (!ok) Ui.toast(this, "Удалено не полностью")
                    refresh()
                }
            }
        }
        add("Информация") { showInfo(f) }

        Ui.menu(this, f.name, labels) { i -> acts[i]() }
    }

    private fun viewer(f: File, mode: String) {
        startActivity(Intent(this, ViewerActivity::class.java).putExtra("file", f.absolutePath).putExtra("mode", mode))
    }

    private fun signApk(f: File) {
        Ui.work(this, "Подпись APK...", {
            val out = Util.uniqueFile(f.parentFile ?: cur, f.nameWithoutExtension + "_signed.apk")
            Zips.sign(this, f, out)
            out
        }) { out ->
            refresh()
            Ui.confirm(this, "Готово: " + out.name + "\nУстановить сейчас?") { Util.installApk(this, out) }
        }
    }

    private fun extractHere(f: File) {
        val dest = Util.uniqueFile(f.parentFile ?: cur, f.nameWithoutExtension)
        Ui.work(this, "Распаковка...", { Zips.extract(f, dest) }) { n ->
            Ui.toast(this, "Файлов: $n\n" + dest.absolutePath)
            refresh()
        }
    }

    private fun compress(f: File) {
        val dest = Util.uniqueFile(f.parentFile ?: cur, f.name + ".zip")
        Ui.work(this, "Сжатие...", { Zips.compress(f, dest) }) {
            Ui.toast(this, "Создан: " + dest.name)
            refresh()
        }
    }

    private fun shareIt(f: File) {
        if (f.isFile) {
            try { Util.share(this, f) } catch (e: Exception) { Ui.toast(this, "Не удалось поделиться: " + e.message) }
        } else {
            Ui.work(this, "Упаковка папки...", {
                val d = File(cacheDir, "share")
                d.mkdirs()
                val z = File(d, f.name + ".zip")
                z.delete()
                Zips.compress(f, z)
                z
            }) { z -> Util.share(this, z) }
        }
    }

    private fun showInfo(f: File) {
        Ui.work(this, "Подсчёт...", { if (f.isDirectory) Util.dirSize(f) else f.length() }) { sz ->
            val t = "Путь: " + f.absolutePath + "\n" +
                "Тип: " + (if (f.isDirectory) "папка" else Util.mime(f.name)) + "\n" +
                "Размер: " + Util.size(sz) + " (" + sz + " байт)\n" +
                "Изменён: " + Util.date(f.lastModified()) + "\n" +
                "Чтение: " + f.canRead() + "  Запись: " + f.canWrite()
            Ui.info(this, f.name, t)
        }
    }
}
