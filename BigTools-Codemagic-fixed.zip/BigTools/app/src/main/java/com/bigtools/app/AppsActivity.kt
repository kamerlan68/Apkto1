package com.bigtools.app

import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Extractor: список приложений, достать APK, поделиться, открыть внутри, проверить. */
class AppsActivity : Activity() {
    class AppRow(val label: String, val pkg: String, val version: String, val info: ApplicationInfo, val system: Boolean)

    private var allApps: List<AppRow> = emptyList()
    private var shown: List<AppRow> = emptyList()
    private var showSystem = false
    private lateinit var search: EditText
    private lateinit var sysBtn: Button
    private lateinit var count: TextView
    private val adapter = Adapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.root(this)
        root.addView(Ui.titleBar(this, "BigTools - Приложения / Extractor"))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        search = EditText(this)
        search.hint = "Поиск по имени или пакету"
        search.typeface = Ui.MONO
        search.textSize = 13f
        search.setSingleLine(true)
        Ui.sunken(search, Ui.WHITE, 6)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { filter() }
        })
        top.addView(search, Ui.lp(0, Ui.WRAP, 1f, Ui.dp(this, 3)))
        sysBtn = Ui.button(this, "Система: нет") {
            showSystem = !showSystem
            sysBtn.text = if (showSystem) "Система: да" else "Система: нет"
            filter()
        }
        top.addView(sysBtn, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, Ui.dp(this, 3)))
        root.addView(top, Ui.lp(Ui.MATCH, Ui.WRAP))

        count = Ui.label(this, "", 11f)
        count.setPadding(Ui.dp(this, 6), 0, Ui.dp(this, 6), Ui.dp(this, 2))
        root.addView(count)

        val list = ListView(this)
        list.divider = ColorDrawable(Ui.DARK)
        list.dividerHeight = 1
        list.adapter = adapter
        Ui.sunken(list, Ui.WHITE, 2)
        list.setOnItemClickListener { _, _, pos, _ -> menu(shown[pos]) }
        root.addView(list, Ui.lp(Ui.MATCH, Ui.MATCH, 1f, Ui.dp(this, 4)))
        setContentView(root)

        load()
    }

    @Suppress("DEPRECATION")
    private fun load() {
        Ui.work(this, "Загрузка списка приложений...", {
            val pm = packageManager
            val out = ArrayList<AppRow>()
            for (ai in pm.getInstalledApplications(0)) {
                var ver = ""
                try { ver = pm.getPackageInfo(ai.packageName, 0).versionName ?: "" } catch (_: Exception) {}
                out.add(AppRow(pm.getApplicationLabel(ai).toString(), ai.packageName, ver, ai, (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0))
            }
            out.sortBy { it.label.lowercase() }
            out as List<AppRow>
        }) { l ->
            allApps = l
            filter()
        }
    }

    private fun filter() {
        val q = search.text.toString().trim().lowercase()
        shown = allApps.filter {
            (showSystem || !it.system) && (q.isEmpty() || it.label.lowercase().contains(q) || it.pkg.lowercase().contains(q))
        }
        count.text = "Приложений: " + shown.size + " (всего " + allApps.size + ")"
        adapter.notifyDataSetChanged()
    }

    inner class Adapter : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row: LinearLayout
            if (convertView == null) {
                row = LinearLayout(this@AppsActivity)
                row.orientation = LinearLayout.VERTICAL
                val p = Ui.dp(this@AppsActivity, 8)
                row.setPadding(p, p, p, p)
                row.addView(Ui.label(this@AppsActivity, "", 14f, true))
                row.addView(Ui.label(this@AppsActivity, "", 11f))
            } else {
                row = convertView as LinearLayout
            }
            val a = shown[position]
            (row.getChildAt(0) as TextView).text = a.label
            (row.getChildAt(1) as TextView).text = a.pkg + "  v" + a.version + (if (a.system) "  [SYS]" else "")
            row.setBackgroundColor(if (position % 2 == 0) Ui.WHITE else 0xFFEEEEEE.toInt())
            return row
        }
    }

    private fun safe(s: String): String = s.replace(Regex("[^A-Za-z0-9А-Яа-я._-]"), "_")

    /** Копирует APK (или все части split-приложения в .apks) в папку dest. */
    private fun extractApk(a: AppRow, dest: File): File {
        dest.mkdirs()
        val src = File(a.info.sourceDir)
        val splits = a.info.splitSourceDirs
        val base = safe(a.label) + "_" + safe(a.version)
        if (splits == null || splits.isEmpty()) {
            val out = Util.uniqueFile(dest, "$base.apk")
            Util.copyFile(src, out)
            return out
        }
        val out = Util.uniqueFile(dest, "$base.apks")
        ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { z ->
            val all = ArrayList<File>()
            all.add(src)
            for (s in splits) all.add(File(s))
            for (f in all) {
                z.putNextEntry(ZipEntry(f.name))
                FileInputStream(f).use { it.copyTo(z, 64 * 1024) }
                z.closeEntry()
            }
        }
        return out
    }

    private fun menu(a: AppRow) {
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        fun add(l: String, f: () -> Unit) { labels.add(l); acts.add(f) }

        add("Извлечь APK в /BigTools/Apps") {
            Ui.work(this, "Извлечение APK...", { extractApk(a, Util.appDir("Apps")) }) { f ->
                Ui.toast(this, "Сохранено:\n" + f.absolutePath + "\n(" + Util.size(f.length()) + ")")
            }
        }
        add("Поделиться приложением (APK)") {
            Ui.work(this, "Подготовка APK...", {
                val d = File(cacheDir, "share")
                d.deleteRecursively()
                extractApk(a, d)
            }) { f -> Util.share(this, f) }
        }
        add("Открыть внутри APK (копия)") {
            Ui.work(this, "Копирование APK...", { extractApk(a, Util.appDir("Extracted")) }) { f ->
                startActivity(Intent(this, ZipActivity::class.java).putExtra("zip", f.absolutePath))
            }
        }
        add("Проверить на вирусы") {
            startActivity(Intent(this, ScanActivity::class.java).putExtra("path", a.info.sourceDir))
        }
        add("Информация") { showInfo(a) }
        add("Запустить") {
            val i = packageManager.getLaunchIntentForPackage(a.pkg)
            if (i != null) startActivity(i) else Ui.toast(this, "У приложения нет экрана запуска")
        }
        add("Настройки приложения") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.pkg)))
        }
        add("Удалить приложение") {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg)))
        }
        Ui.menu(this, a.label, labels) { i -> acts[i]() }
    }

    @Suppress("DEPRECATION")
    private fun showInfo(a: AppRow) {
        val sb = StringBuilder()
        sb.append("Имя: ").append(a.label).append('\n')
        sb.append("Пакет: ").append(a.pkg).append('\n')
        sb.append("Версия: ").append(a.version).append('\n')
        try {
            val pi = packageManager.getPackageInfo(a.pkg, PackageManager.GET_PERMISSIONS)
            sb.append("Код версии: ").append(pi.versionCode).append('\n')
            sb.append("Установлено: ").append(Util.date(pi.firstInstallTime)).append('\n')
            sb.append("Обновлено: ").append(Util.date(pi.lastUpdateTime)).append('\n')
            sb.append("Разрешений запрошено: ").append(pi.requestedPermissions?.size ?: 0).append('\n')
        } catch (_: Exception) {}
        sb.append("Target SDK: ").append(a.info.targetSdkVersion).append('\n')
        sb.append("Min SDK: ").append(a.info.minSdkVersion).append('\n')
        sb.append("APK: ").append(a.info.sourceDir).append('\n')
        sb.append("Размер APK: ").append(Util.size(File(a.info.sourceDir).length())).append('\n')
        val sp = a.info.splitSourceDirs
        if (sp != null && sp.isNotEmpty()) sb.append("Split-частей: ").append(sp.size).append('\n')
        sb.append("Данные: ").append(a.info.dataDir).append('\n')
        sb.append("Системное: ").append(if (a.system) "да" else "нет")
        Ui.info(this, a.label, sb.toString())
    }
}
