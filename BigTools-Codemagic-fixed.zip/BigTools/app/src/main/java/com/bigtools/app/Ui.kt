package com.bigtools.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.StateListDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Олдскульный серый стиль в духе старых окон. */
object Ui {
    val GRAY = 0xFFC0C0C0.toInt()
    val DARK = 0xFF808080.toInt()
    val WHITE = 0xFFFFFFFF.toInt()
    val BLACK = 0xFF000000.toInt()
    val MONO: Typeface = Typeface.MONOSPACE

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    const val RAISED = 0
    const val PRESSED = 1
    const val SUNKEN = 2

    class Bevel(private val mode: Int, private val fill: Int) : Drawable() {
        private val p = Paint()
        private fun r(c: Canvas, l: Float, t: Float, rr: Float, b: Float, col: Int) {
            p.color = col
            c.drawRect(l, t, rr, b, p)
        }
        override fun draw(c: Canvas) {
            val w = bounds.width().toFloat()
            val h = bounds.height().toFloat()
            p.style = Paint.Style.FILL
            r(c, 0f, 0f, w, h, fill)
            when (mode) {
                RAISED -> {
                    r(c, 0f, 0f, w, 2f, WHITE); r(c, 0f, 0f, 2f, h, WHITE)
                    r(c, 0f, h - 2f, w, h, DARK); r(c, w - 2f, 0f, w, h, DARK)
                    r(c, 0f, h - 1f, w, h, BLACK); r(c, w - 1f, 0f, w, h, BLACK)
                }
                PRESSED -> {
                    r(c, 0f, 0f, w, 2f, DARK); r(c, 0f, 0f, 2f, h, DARK)
                    r(c, 0f, 0f, w, 1f, BLACK); r(c, 0f, 0f, 1f, h, BLACK)
                    r(c, 0f, h - 1f, w, h, WHITE); r(c, w - 1f, 0f, w, h, WHITE)
                }
                else -> {
                    r(c, 0f, 0f, w, 2f, DARK); r(c, 0f, 0f, 2f, h, DARK)
                    r(c, 0f, 0f, w, 1f, BLACK); r(c, 0f, 0f, 1f, h, BLACK)
                    r(c, 0f, h - 2f, w, h, WHITE); r(c, w - 2f, 0f, w, h, WHITE)
                }
            }
        }
        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(cf: ColorFilter?) {}
        @Suppress("OVERRIDE_DEPRECATION")
        override fun getOpacity(): Int = PixelFormat.OPAQUE
    }

    fun button(c: Context, text: String, onClick: () -> Unit): Button {
        val b = Button(c)
        b.text = text
        b.isAllCaps = false
        b.typeface = Typeface.create(MONO, Typeface.BOLD)
        b.textSize = 13f
        b.setTextColor(BLACK)
        b.stateListAnimator = null
        val sl = StateListDrawable()
        sl.addState(intArrayOf(android.R.attr.state_pressed), Bevel(PRESSED, GRAY))
        sl.addState(intArrayOf(), Bevel(RAISED, GRAY))
        b.background = sl
        val ph = dp(c, 10)
        val pv = dp(c, 8)
        b.setPadding(ph, pv, ph, pv)
        b.minHeight = 0
        b.minimumHeight = 0
        b.minWidth = 0
        b.minimumWidth = 0
        b.setOnClickListener { onClick() }
        return b
    }

    fun label(c: Context, text: String, size: Float = 14f, bold: Boolean = false): TextView {
        val t = TextView(c)
        t.text = text
        t.textSize = size
        t.setTextColor(BLACK)
        t.typeface = Typeface.create(MONO, if (bold) Typeface.BOLD else Typeface.NORMAL)
        return t
    }

    fun titleBar(c: Context, text: String): TextView {
        val t = label(c, text, 15f, true)
        t.setTextColor(WHITE)
        t.setBackgroundColor(BLACK)
        val p = dp(c, 8)
        t.setPadding(p, p, p, p)
        t.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        return t
    }

    fun sunken(v: View, fill: Int = WHITE, pad: Int = 4) {
        v.background = Bevel(SUNKEN, fill)
        val p = dp(v.context, pad)
        v.setPadding(p, p, p, p)
    }

    fun root(a: Activity): LinearLayout {
        val l = LinearLayout(a)
        l.orientation = LinearLayout.VERTICAL
        l.setBackgroundColor(GRAY)
        a.window.statusBarColor = BLACK
        a.window.navigationBarColor = BLACK
        return l
    }

    fun lp(w: Int, h: Int, weight: Float = 0f, m: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h, weight)
        p.setMargins(m, m, m, m)
        return p
    }

    val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_LONG).show()

    fun menu(c: Context, title: String, labels: List<String>, onPick: (Int) -> Unit) {
        AlertDialog.Builder(c).setTitle(title)
            .setItems(labels.toTypedArray()) { _, i -> onPick(i) }
            .setNegativeButton("Отмена", null).show()
    }

    fun confirm(c: Context, msg: String, onYes: () -> Unit) {
        AlertDialog.Builder(c).setMessage(msg)
            .setPositiveButton("Да") { _, _ -> onYes() }
            .setNegativeButton("Нет", null).show()
    }

    fun ask(c: Context, title: String, def: String, onOk: (String) -> Unit) {
        val e = EditText(c)
        e.setText(def)
        e.typeface = MONO
        e.setSingleLine(true)
        e.setSelection(def.length)
        AlertDialog.Builder(c).setTitle(title).setView(e)
            .setPositiveButton("OK") { _, _ -> onOk(e.text.toString().trim()) }
            .setNegativeButton("Отмена", null).show()
    }

    fun info(c: Context, title: String, text: String) {
        val t = label(c, text, 12f)
        t.setTextIsSelectable(true)
        val p = dp(c, 12)
        t.setPadding(p, p, p, p)
        val sv = android.widget.ScrollView(c)
        sv.addView(t)
        AlertDialog.Builder(c).setTitle(title).setView(sv).setPositiveButton("OK", null).show()
    }

    /** Фоновая задача с окном «Подождите». */
    fun <T> work(a: Activity, msg: String, job: () -> T, done: (T) -> Unit) {
        val d = AlertDialog.Builder(a).setMessage(msg).setCancelable(false).create()
        d.show()
        Thread {
            var res: T? = null
            var err: Throwable? = null
            try { res = job() } catch (e: Throwable) { err = e }
            val fe: Throwable? = err
            val fr: T? = res
            a.runOnUiThread {
                try { d.dismiss() } catch (_: Exception) {}
                if (fe != null) {
                    toast(a, "Ошибка: " + (fe.message ?: fe.javaClass.simpleName))
                } else {
                    @Suppress("UNCHECKED_CAST")
                    done(fr as T)
                }
            }
        }.start()
    }

    fun centerRow(c: Context): LinearLayout {
        val l = LinearLayout(c)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        return l
    }
}
