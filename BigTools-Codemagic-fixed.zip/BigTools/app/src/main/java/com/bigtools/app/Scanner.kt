package com.bigtools.app

import android.content.Context
import android.content.pm.PackageManager
import java.io.File
import java.io.FileInputStream

/** Эвристический сканер: хеши, права APK, строки в dex, маскировка файлов, опасные скрипты. */
object Scanner {
    class Result(val level: Int, val score: Int, val title: String, val report: String)

    private val PERM_W = mapOf(
        "android.permission.SEND_SMS" to 2,
        "android.permission.RECEIVE_SMS" to 1,
        "android.permission.READ_SMS" to 2,
        "android.permission.READ_CONTACTS" to 1,
        "android.permission.READ_CALL_LOG" to 1,
        "android.permission.CALL_PHONE" to 1,
        "android.permission.RECORD_AUDIO" to 1,
        "android.permission.SYSTEM_ALERT_WINDOW" to 2,
        "android.permission.BIND_ACCESSIBILITY_SERVICE" to 3,
        "android.permission.BIND_DEVICE_ADMIN" to 3,
        "android.permission.REQUEST_INSTALL_PACKAGES" to 1,
        "android.permission.INSTALL_PACKAGES" to 3,
        "android.permission.DELETE_PACKAGES" to 2,
        "android.permission.WRITE_SECURE_SETTINGS" to 3,
        "android.permission.BIND_NOTIFICATION_LISTENER_SERVICE" to 2,
        "android.permission.MANAGE_EXTERNAL_STORAGE" to 1,
        "android.permission.QUERY_ALL_PACKAGES" to 1
    )

    private class Pat(val text: String, val w: Int, val desc: String)

    private val DEX_PATS = listOf(
        Pat("sendTextMessage", 2, "Отправка SMS из кода"),
        Pat("sendMultipartTextMessage", 2, "Отправка SMS из кода"),
        Pat("android.provider.Telephony.SMS_RECEIVED", 1, "Перехват входящих SMS"),
        Pat("DexClassLoader", 1, "Динамическая загрузка кода (DexClassLoader)"),
        Pat("/system/xbin/su", 1, "Работа с root (su)"),
        Pat("su -c", 2, "Выполнение команд через su"),
        Pat("chmod 777", 2, "Смена прав chmod 777"),
        Pat("pm install", 2, "Тихая установка пакетов (pm install)"),
        Pat("pm grant", 2, "Выдача прав через pm grant"),
        Pat("api.telegram.org/bot", 3, "Отправка данных в Telegram-бот"),
        Pat("discord.com/api/webhooks", 3, "Отправка данных через Discord webhook"),
        Pat("files have been encrypted", 3, "Текст похож на шифровальщик"),
        Pat("DevicePolicyManager", 1, "Администратор устройства")
    )

    private val SCRIPT_PATS = listOf(
        Pair(Regex("""curl[^\n]*\|\s*(ba)?sh"""), "Скачивание и запуск из сети (curl | sh)"),
        Pair(Regex("""wget[^\n]*\|\s*(ba)?sh"""), "Скачивание и запуск из сети (wget | sh)"),
        Pair(Regex("""base64\s+-d[^\n]*\|\s*(ba)?sh"""), "Запуск декодированного base64"),
        Pair(Regex("""rm\s+-rf\s+/(\s|\*|$)"""), "Удаление корня (rm -rf /)"),
        Pair(Regex("""eval\s*\(.*base64_decode"""), "eval(base64_decode(...))"),
        Pair(Regex("""powershell[^\n]*-enc""", RegexOption.IGNORE_CASE), "PowerShell с закодированной командой")
    )

    private val MEDIA_EXT = setOf("jpg", "jpeg", "png", "gif", "bmp", "webp", "mp3", "mp4", "mkv", "avi", "wav", "ogg", "txt", "pdf", "mov")

    private var hashCache: Map<String, String>? = null

    private fun hashes(c: Context): Map<String, String> {
        hashCache?.let { return it }
        val m = HashMap<String, String>()
        fun parse(text: String) {
            for (line in text.lines()) {
                if (line.startsWith("#")) continue
                val t = line.trim().split(Regex("\\s+"))
                val h = t.firstOrNull { it.length == 64 && it.all { ch -> ch.isDigit() || ch in 'a'..'f' || ch in 'A'..'F' } } ?: continue
                m[h.lowercase()] = t.filter { it != h }.joinToString(" ").ifEmpty { "без названия" }
            }
        }
        try { parse(c.assets.open("hashes.txt").bufferedReader().readText()) } catch (_: Exception) {}
        try {
            val extra = File(Util.storageRoot(), "BigTools/hashes.txt")
            if (extra.isFile) parse(extra.readText())
        } catch (_: Exception) {}
        hashCache = m
        return m
    }

    private fun readHead(f: File, n: Int): ByteArray {
        FileInputStream(f).use { i ->
            val buf = ByteArray(n)
            var got = 0
            while (got < n) {
                val r = i.read(buf, got, n - got)
                if (r < 0) break
                got += r
            }
            return buf.copyOf(got)
        }
    }

    private fun magic(h: ByteArray): String {
        if (h.size >= 4 && h[0].toInt() == 0x50 && h[1].toInt() == 0x4B && h[2].toInt() == 0x03 && h[3].toInt() == 0x04) return "zip"
        if (h.size >= 4 && h[0].toInt() == 0x7F && h[1].toInt() == 0x45 && h[2].toInt() == 0x4C && h[3].toInt() == 0x46) return "elf"
        if (h.size >= 2 && h[0].toInt() == 0x4D && h[1].toInt() == 0x5A) return "pe"
        if (h.size >= 4 && h[0].toInt() == 0x64 && h[1].toInt() == 0x65 && h[2].toInt() == 0x78 && h[3].toInt() == 0x0A) return "dex"
        if (h.size >= 2 && h[0].toInt() == 0x23 && h[1].toInt() == 0x21) return "script"
        return "other"
    }

    private fun has(h: ByteArray, n: ByteArray): Boolean {
        if (n.isEmpty() || h.size < n.size) return false
        val first = n[0]
        val last = h.size - n.size
        var i = 0
        while (i <= last) {
            if (h[i] == first) {
                var j = 1
                while (j < n.size && h[i + j] == n[j]) j++
                if (j == n.size) return true
            }
            i++
        }
        return false
    }

    fun scan(c: Context, f: File): Result {
        val findings = ArrayList<String>()
        val infos = ArrayList<String>()
        var score = 0
        var confirmed = false

        val sha = Util.hash(f, "SHA-256")
        val md5 = Util.hash(f, "MD5")
        val db = hashes(c)
        val known = db[sha]
        if (known != null) { confirmed = true; findings.add("Хеш совпал с базой: $known") }

        val head = readHead(f, 4096)
        if (String(head, Charsets.ISO_8859_1).contains("EICAR-STANDARD-ANTIVIRUS-TEST-FILE")) {
            confirmed = true
            findings.add("Тестовая сигнатура EICAR")
        }
        val kind = magic(head)
        val name = f.name
        val ext = Util.ext(name)

        if (ext in MEDIA_EXT && (kind == "elf" || kind == "pe" || kind == "dex")) {
            score += 4; findings.add("Файл .$ext на самом деле исполняемый ($kind)")
        } else if (ext in MEDIA_EXT && kind == "zip") {
            score += 3; findings.add("Файл .$ext на самом деле архив/APK")
        }
        if (ext == "apk" && kind != "zip") { score += 2; findings.add("Расширение .apk, но это не архив") }
        if (Regex(""".*\.(jpg|jpeg|png|pdf|doc|docx|txt|mp3|mp4)\.(apk|exe|bat|sh|scr|js|vbs|jar)$""", RegexOption.IGNORE_CASE).matches(name)) {
            score += 3; findings.add("Двойное расширение — типичная маскировка")
        }
        if (kind == "pe") { score += 1; findings.add("Исполняемый файл Windows (PE)") }
        if (kind == "elf") { score += 1; findings.add("Исполняемый файл ELF") }

        if (kind == "zip") {
            try {
                score += scanZip(c, f, findings, infos)
            } catch (e: Exception) {
                score += 1
                findings.add("Архив не читается или повреждён: " + (e.message ?: e.javaClass.simpleName))
            }
        }

        if ((Util.isText(name) || kind == "script") && f.length() < 2_000_000) {
            val t = String(readHead(f, 300_000), Charsets.UTF_8)
            for ((re, d) in SCRIPT_PATS) if (re.containsMatchIn(t)) { score += 3; findings.add(d) }
        }

        val level: Int
        val title: String
        if (confirmed || score >= 100) { level = 3; title = "ВРЕДОНОСНЫЙ (совпадение с базой/сигнатурой)" }
        else if (score >= 8) { level = 2; title = "ВЫСОКИЙ РИСК" }
        else if (score >= 3) { level = 1; title = "ПОДОЗРИТЕЛЬНО" }
        else { level = 0; title = "ЧИСТО (угроз не найдено)" }

        val sb = StringBuilder()
        sb.append("Файл: ").append(name).append('\n')
        sb.append("Размер: ").append(Util.size(f.length())).append('\n')
        sb.append("SHA-256: ").append(sha).append('\n')
        sb.append("MD5: ").append(md5).append("\n\n")
        sb.append("ВЕРДИКТ: ").append(title).append(" [баллы: ").append(score).append("]\n")
        if (infos.isNotEmpty()) { sb.append("\nИнформация:\n"); infos.forEach { sb.append(" * ").append(it).append('\n') } }
        if (findings.isNotEmpty()) { sb.append("\nНаходки:\n"); findings.forEach { sb.append(" ! ").append(it).append('\n') } }
        sb.append("\nПроверка эвристическая (хеши, права, признаки в коде). Она не заменяет полноценный антивирус. ")
        sb.append("Высокий балл не всегда вирус — смотри находки.\n")
        sb.append("Свои хеши можно добавить в /sdcard/BigTools/hashes.txt (строка: имя sha256).\n")
        return Result(level, score, title, sb.toString())
    }

    private fun scanZip(c: Context, f: File, findings: MutableList<String>, infos: MutableList<String>): Int {
        var score = 0
        val ents = Zips.list(f)
        var total = 0L
        for (e in ents) if (e.size > 0) total += e.size
        infos.add("Записей в архиве: " + ents.size + ", распаковано ~" + Util.size(total))
        if (ents.size > 20000) { score += 1; findings.add("Очень много файлов в архиве") }
        if (total > 4_000_000_000L || (f.length() > 0 && total / f.length() > 1000 && total > 1_000_000_000L)) {
            score += 3; findings.add("Похоже на zip-бомбу (огромный коэффициент сжатия)")
        }
        if (ents.any { it.name.contains("../") || it.name.startsWith("/") }) {
            score += 3; findings.add("Пути с ../ или / (попытка выйти из папки при распаковке)")
        }
        val isApk = ents.any { it.name == "AndroidManifest.xml" } && ents.any { Regex("classes\\d*\\.dex").matches(it.name) }
        if (isApk) {
            score += scanApk(c, f, ents, findings, infos)
        } else {
            val exe = ents.filter { val x = Util.ext(it.name); x == "apk" || x == "dex" || x == "exe" || x == "bat" || x == "scr" || x == "jar" }
            if (exe.isNotEmpty()) {
                score += 1
                findings.add("Внутри исполняемое: " + exe.take(5).joinToString { it.name } + if (exe.size > 5) " ..." else "")
            }
        }
        return score
    }

    @Suppress("DEPRECATION")
    private fun scanApk(c: Context, f: File, ents: List<Zips.Ent>, findings: MutableList<String>, infos: MutableList<String>): Int {
        var score = 0
        val flags = PackageManager.GET_PERMISSIONS or PackageManager.GET_SERVICES or PackageManager.GET_RECEIVERS
        val pi = c.packageManager.getPackageArchiveInfo(f.absolutePath, flags)
        if (pi == null) {
            score += 2
            findings.add("Не удалось разобрать манифест APK (повреждён или нестандартный)")
        } else {
            infos.add("Пакет: " + pi.packageName + ", версия: " + (pi.versionName ?: "?"))
            val perms = ArrayList<String>()
            pi.requestedPermissions?.forEach { p ->
                val w = PERM_W[p]
                if (w != null) { score += w; perms.add(p.substringAfterLast('.')) }
            }
            infos.add("Запрошено разрешений: " + (pi.requestedPermissions?.size ?: 0))
            if (perms.isNotEmpty()) findings.add("Чувствительные разрешения: " + perms.joinToString(", "))
            pi.services?.forEach { s ->
                when (s.permission) {
                    "android.permission.BIND_ACCESSIBILITY_SERVICE" -> { score += 3; findings.add("Служба доступности: " + s.name) }
                    "android.permission.BIND_NOTIFICATION_LISTENER_SERVICE" -> { score += 2; findings.add("Чтение уведомлений: " + s.name) }
                    else -> {}
                }
            }
            pi.receivers?.forEach { r ->
                if (r.permission == "android.permission.BIND_DEVICE_ADMIN") { score += 3; findings.add("Администратор устройства: " + r.name) }
            }
        }

        val hit = LinkedHashSet<String>()
        for (e in ents) {
            if (!Regex("classes\\d*\\.dex").matches(e.name)) continue
            val d = Zips.readEntry(f, e.name, 24 * 1024 * 1024)
            for (p in DEX_PATS) {
                if (p.desc in hit) continue
                if (has(d, p.text.toByteArray(Charsets.ISO_8859_1))) {
                    hit.add(p.desc)
                    score += p.w
                    findings.add("В коде: " + p.desc)
                }
            }
        }

        var embedded = 0
        var elfs = 0
        var checked = 0
        for (e in ents) {
            if (e.dir) continue
            val x = Util.ext(e.name)
            val inData = e.name.startsWith("assets/") || e.name.startsWith("res/raw/")
            if (inData && (x == "apk" || x == "dex" || x == "jar")) embedded++
            else if (inData && e.size > 1000 && checked < 200) {
                checked++
                try { if (magic(Zips.readEntry(f, e.name, 8)) == "elf") elfs++ } catch (_: Exception) {}
            }
        }
        if (embedded > 0) { score += 2; findings.add("Вложенный код внутри assets/raw ($embedded шт.)") }
        if (elfs > 0) { score += 2; findings.add("Исполняемые ELF внутри assets/raw ($elfs шт.)") }
        return score
    }
}
