package com.bigtools.app

import android.app.Activity
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.io.FileInputStream

/** Просмотр / правка: текст (с сохранением), бинарный XML (декодер), HEX. */
class ViewerActivity : Activity() {
    private var zip: File? = null
    private var entry: String? = null
    private var file: File? = null
    private var editable = false
    private lateinit var edit: EditText
    private lateinit var info: TextView

    private val textLimit = 1_000_000
    private val hexLimit = 64 * 1024

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val z = intent.getStringExtra("zip")
        if (z != null) { zip = File(z); entry = intent.getStringExtra("entry") }
        val fp = intent.getStringExtra("file")
        if (fp != null) file = File(fp)
        val mode = intent.getStringExtra("mode") ?: "auto"
        val shownName = entry ?: file?.name ?: "?"

        val root = Ui.root(this)
        root.addView(Ui.titleBar(this, "BigTools - " + shownName.substringAfterLast('/')))
        info = Ui.label(this, "Загрузка...", 11f)
        info.setPadding(Ui.dp(this, 6), Ui.dp(this, 4), Ui.dp(this, 6), Ui.dp(this, 4))
        root.addView(info)

        edit = EditText(this)
        edit.typeface = Ui.MONO
        edit.textSize = 12f
        edit.setTextColor(Ui.BLACK)
        edit.gravity = Gravity.TOP or Gravity.START
        edit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        edit.setHorizontallyScrolling(false)
        Ui.sunken(edit, Ui.WHITE, 6)
        root.addView(edit, Ui.lp(Ui.MATCH, Ui.MATCH, 1f, Ui.dp(this, 4)))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        val m = Ui.dp(this, 3)
        bar.addView(Ui.button(this, "Сохранить") { save() }, Ui.lp(0, Ui.WRAP, 1f, m))
        bar.addView(Ui.button(this, "Закрыть") { finish() }, Ui.lp(0, Ui.WRAP, 1f, m))
        root.addView(bar, Ui.lp(Ui.MATCH, Ui.WRAP))
        setContentView(root)

        Ui.work(this, "Чтение...", { load(mode) }) { r ->
            editable = r.third
            info.text = r.first
            edit.setText(r.second)
            if (!editable) {
                edit.keyListener = null
                edit.setTextIsSelectable(true)
            }
        }
    }

    /** Возвращает (описание, текст, можно ли править). */
    private fun load(mode: String): Triple<String, String, Boolean> {
        val total: Long
        val data: ByteArray
        val z = zip
        val e = entry
        val f = file
        if (z != null && e != null) {
            val ent = Zips.list(z).firstOrNull { it.name == e }
            total = ent?.size ?: 0L
            data = Zips.readEntry(z, e, textLimit)
        } else if (f != null) {
            total = f.length()
            data = FileInputStream(f).use { i ->
                val buf = ByteArray(minOf(total, textLimit.toLong()).toInt())
                var got = 0
                while (got < buf.size) {
                    val r = i.read(buf, got, buf.size - got)
                    if (r < 0) break
                    got += r
                }
                buf.copyOf(got)
            }
        } else throw IllegalStateException("Нет файла")

        if (mode != "hex" && Axml.looksLikeAxml(data)) {
            return try {
                Triple("Бинарный XML, декодирован (только просмотр). Размер: " + Util.size(total), Axml.decode(data), false)
            } catch (ex: Exception) {
                Triple("Не удалось декодировать XML (" + ex.message + "). Показан HEX.", hex(data), false)
            }
        }
        val truncated = total > data.size
        var binary = false
        val n = minOf(data.size, 8000)
        for (i in 0 until n) if (data[i].toInt() == 0) { binary = true; break }
        if (mode != "hex" && !binary && !truncated) {
            return Triple("Текст UTF-8, " + Util.size(total) + ". Можно править и сохранить.", String(data, Charsets.UTF_8), true)
        }
        val why = if (truncated) "большой файл, показано начало" else "бинарный файл"
        return Triple("HEX (" + why + "), только просмотр. Размер: " + Util.size(total), hex(data), false)
    }

    private fun hex(d: ByteArray): String {
        val n = minOf(d.size, hexLimit)
        val sb = StringBuilder()
        var i = 0
        while (i < n) {
            sb.append(String.format("%06x  ", i))
            val asc = StringBuilder()
            for (k in 0 until 16) {
                if (i + k < n) {
                    val b = d[i + k].toInt() and 0xFF
                    sb.append(String.format("%02x ", b))
                    asc.append(if (b in 32..126) b.toChar() else '.')
                } else sb.append("   ")
            }
            sb.append(' ').append(asc).append('\n')
            i += 16
        }
        if (d.size > hexLimit) sb.append("... (показано первые ").append(hexLimit / 1024).append(" КБ)")
        return sb.toString()
    }

    private fun save() {
        if (!editable) { Ui.toast(this, "Этот файл только для просмотра"); return }
        val text = edit.text.toString()
        val z = zip
        val e = entry
        val f = file
        Ui.work(this, "Сохранение...", {
            if (z != null && e != null) {
                val tmp = File(cacheDir, "edit_" + System.nanoTime())
                tmp.writeText(text, Charsets.UTF_8)
                Zips.backupOnce(z)
                Zips.rewrite(z, mapOf<String, File?>(e to tmp))
                tmp.delete()
            } else if (f != null) {
                f.writeText(text, Charsets.UTF_8)
            }
            Unit
        }) {
            setResult(RESULT_OK)
            Ui.toast(this, "Сохранено" + (if (z != null && Util.ext(z.name) == "apk") ". Не забудь подписать APK." else ""))
        }
    }
}
