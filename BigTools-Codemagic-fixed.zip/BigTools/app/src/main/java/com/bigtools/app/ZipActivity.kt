package com.bigtools.app

import android.app.Activity
import android.content.Intent
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import java.io.File
import java.util.TreeSet

/** Проводник внутри ZIP/APK: просмотр, извлечение, замена, удаление, подпись. */
class ZipActivity : Activity() {
    class Row(val label: String, val full: String, val dir: Boolean, val size: Long, val csize: Long)

    private lateinit var zip: File
    private var all: List<Zips.Ent> = emptyList()
    private var rows: List<Row> = emptyList()
    private var prefix = ""
    private var pendingReplace: String? = null
    private lateinit var titleView: TextView
    private lateinit var pathView: TextView
    private lateinit var list: ListView
    private val adapter = Adapter()

    private val REQ_PICK = 11
    private val REQ_VIEW = 12

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = intent.getStringExtra("zip")
        if (p == null) { finish(); return }
        zip = File(p)

        val root = Ui.root(this)
        titleView = Ui.titleBar(this, "BigTools - " + zip.name)
        root.addView(titleView)
        pathView = Ui.label(this, "", 12f)
        Ui.sunken(pathView, Ui.WHITE, 6)
        root.addView(pathView, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, Ui.dp(this, 4)))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        val m = Ui.dp(this, 2)
        bar.addView(Ui.button(this, "Вверх") { up() }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, m))
        bar.addView(Ui.button(this, "Распаковать всё") { extractAll() }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, m))
        bar.addView(Ui.button(this, "Добавить файл") { pendingReplace = null; pick() }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, m))
        if (Util.ext(zip.name) == "apk") {
            bar.addView(Ui.button(this, "Подписать") { signIt() }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, m))
            bar.addView(Ui.button(this, "Установить") { Util.installApk(this, zip) }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, m))
        }
        bar.addView(Ui.button(this, "Вирусы") {
            startActivity(Intent(this, ScanActivity::class.java).putExtra("path", zip.absolutePath))
        }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, m))
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(bar)
        root.addView(hs, Ui.lp(Ui.MATCH, Ui.WRAP))

        list = ListView(this)
        list.divider = ColorDrawable(Ui.DARK)
        list.dividerHeight = 1
        list.adapter = adapter
        Ui.sunken(list, Ui.WHITE, 2)
        list.setOnItemClickListener { _, _, pos, _ ->
            val r = rows[pos]
            if (r.dir) { prefix = r.full; rebuild() } else fileMenu(r)
        }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            val r = rows[pos]
            if (r.dir) dirMenu(r) else fileMenu(r)
            true
        }
        root.addView(list, Ui.lp(Ui.MATCH, Ui.MATCH, 1f, Ui.dp(this, 4)))
        setContentView(root)
        reload()
    }

    override fun onBackPressed() {
        if (prefix.isNotEmpty()) up() else super.onBackPressed()
    }

    private fun up() {
        if (prefix.isEmpty()) { finish(); return }
        val t = prefix.trimEnd('/')
        val i = t.lastIndexOf('/')
        prefix = if (i < 0) "" else t.substring(0, i + 1)
        rebuild()
    }

    private fun reload() {
        Ui.work(this, "Чтение архива...", { Zips.list(zip) }) { l ->
            all = l
            rebuild()
        }
    }

    private fun rebuild() {
        val folders = TreeSet<String>()
        val files = ArrayList<Row>()
        for (e in all) {
            if (!e.name.startsWith(prefix)) continue
            val rest = e.name.substring(prefix.length)
            if (rest.isEmpty()) continue
            val slash = rest.indexOf('/')
            if (slash >= 0) folders.add(rest.substring(0, slash))
            else if (!e.dir) files.add(Row(rest, e.name, false, e.size, e.csize))
        }
        val out = ArrayList<Row>()
        for (f in folders) out.add(Row(f, prefix + f + "/", true, 0, 0))
        out.addAll(files.sortedBy { it.label.lowercase() })
        rows = out
        pathView.text = "/" + prefix + "   (" + all.size + " записей, " + Util.size(zip.length()) + ")"
        adapter.notifyDataSetChanged()
    }

    inner class Adapter : BaseAdapter() {
        override fun getCount(): Int = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row: LinearLayout
            if (convertView == null) {
                row = LinearLayout(this@ZipActivity)
                row.orientation = LinearLayout.VERTICAL
                val p = Ui.dp(this@ZipActivity, 8)
                row.setPadding(p, p, p, p)
                row.addView(Ui.label(this@ZipActivity, "", 14f, true))
                row.addView(Ui.label(this@ZipActivity, "", 11f))
            } else {
                row = convertView as LinearLayout
            }
            val r = rows[position]
            (row.getChildAt(0) as TextView).text = (if (r.dir) "[DIR] " else "      ") + r.label
            (row.getChildAt(1) as TextView).text =
                if (r.dir) "папка" else Util.size(r.size) + "  (в архиве " + Util.size(r.csize) + ")"
            row.setBackgroundColor(if (position % 2 == 0) Ui.WHITE else 0xFFEEEEEE.toInt())
            return row
        }
    }

    private fun fileMenu(r: Row) {
        Ui.menu(this, r.label, listOf(
            "Открыть (просмотр / правка)", "Просмотр HEX", "Извлечь в /BigTools/Extracted",
            "Заменить файлом...", "Удалить из архива", "Информация"
        )) { i ->
            when (i) {
                0 -> viewer(r, "auto")
                1 -> viewer(r, "hex")
                2 -> {
                    val dest = File(Util.appDir("Extracted"), zip.nameWithoutExtension + "/" + r.full)
                    Ui.work(this, "Извлечение...", { Zips.extractEntry(zip, r.full, dest) }) {
                        Ui.toast(this, "Извлечено:\n" + dest.absolutePath)
                    }
                }
                3 -> { pendingReplace = r.full; pick() }
                4 -> Ui.confirm(this, "Удалить " + r.full + " из архива?") { modify(mapOf(r.full to null)) }
                5 -> Ui.info(this, r.label, "Запись: " + r.full + "\nРазмер: " + Util.size(r.size) + " (" + r.size + " байт)\nВ архиве: " + Util.size(r.csize))
                else -> {}
            }
        }
    }

    private fun dirMenu(r: Row) {
        Ui.menu(this, r.label, listOf("Извлечь папку в /BigTools/Extracted", "Удалить папку из архива")) { i ->
            if (i == 0) {
                val dest = File(Util.appDir("Extracted"), zip.nameWithoutExtension)
                Ui.work(this, "Извлечение...", { Zips.extract(zip, dest, r.full) }) { n ->
                    Ui.toast(this, "Файлов: $n\n" + dest.absolutePath)
                }
            } else {
                Ui.confirm(this, "Удалить папку " + r.full + " со всем содержимым?") {
                    val ch = HashMap<String, File?>()
                    for (e in all) if (e.name.startsWith(r.full)) ch[e.name] = null
                    modify(ch)
                }
            }
        }
    }

    private fun viewer(r: Row, mode: String) {
        startActivityForResult(
            Intent(this, ViewerActivity::class.java)
                .putExtra("zip", zip.absolutePath).putExtra("entry", r.full).putExtra("mode", mode),
            REQ_VIEW
        )
    }

    private fun extractAll() {
        val dest = Util.uniqueFile(zip.parentFile ?: Util.storageRoot(), zip.nameWithoutExtension)
        Ui.work(this, "Распаковка...", { Zips.extract(zip, dest) }) { n ->
            Ui.toast(this, "Файлов: $n\n" + dest.absolutePath)
        }
    }

    private fun pick() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        startActivityForResult(i, REQ_PICK)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VIEW && resultCode == RESULT_OK) { reload(); return }
        if (requestCode != REQ_PICK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val target = pendingReplace
        Ui.work(this, "Запись в архив...", {
            val f = Util.copyUriToCache(this, uri)
            val name = target ?: (prefix + f.name)
            Zips.backupOnce(zip)
            Zips.rewrite(zip, mapOf<String, File?>(name to f))
            name
        }) { name ->
            Ui.toast(this, "Записано: $name" + hint())
            reload()
        }
    }

    private fun hint(): String = if (Util.ext(zip.name) == "apk") "\nПосле правки APK нужно подписать." else ""

    private fun modify(changes: Map<String, File?>) {
        Ui.work(this, "Пересборка архива...", {
            Zips.backupOnce(zip)
            Zips.rewrite(zip, changes)
        }) {
            Ui.toast(this, "Готово (копия: " + zip.name + ".bak)" + hint())
            reload()
        }
    }

    private fun signIt() {
        Ui.work(this, "Подпись APK...", {
            val out = Util.uniqueFile(zip.parentFile ?: Util.storageRoot(), zip.nameWithoutExtension + "_signed.apk")
            Zips.sign(this, zip, out)
            out
        }) { out ->
            Ui.confirm(this, "Готово: " + out.name + "\nУстановить сейчас?") { Util.installApk(this, out) }
        }
    }
}
